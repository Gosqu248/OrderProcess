create view query_a3(id_planu, nazwa_planu, opis, poziom_zaawansowania, id_uzytkownika) as
SELECT plan_treningowy.id_planu,
       plan_treningowy.nazwa_planu,
       plan_treningowy.opis,
       plan_treningowy.poziom_zaawansowania,
       plan_treningowy.id_uzytkownika
FROM aplikacja.plan_treningowy
WHERE plan_treningowy.id_uzytkownika = 7;

comment on view query_a3 is 'Wybór planu treningowego dla użytkownika o id 7.';

alter table query_a3
    owner to "2023_urban_grzegorz";

