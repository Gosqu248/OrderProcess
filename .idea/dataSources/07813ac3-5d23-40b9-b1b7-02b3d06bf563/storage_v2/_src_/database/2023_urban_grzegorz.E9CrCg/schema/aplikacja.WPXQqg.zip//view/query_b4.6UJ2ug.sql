create view query_b4(id_produktu, nazwa_produktu, usage_count) as
SELECT pp.id_produktu,
       ps.nazwa_produktu,
       count(pp.id_produktu) AS usage_count
FROM aplikacja.produkt_w_posilku pp
         JOIN aplikacja.produkt_spozywczy ps ON pp.id_produktu = ps.id_produktu
GROUP BY pp.id_produktu, ps.nazwa_produktu
ORDER BY (count(pp.id_produktu)) DESC;

comment on view query_b4 is 'Wybór najczęściej spożywanych produktów przez użytkowników';

alter table query_b4
    owner to "2023_urban_grzegorz";

