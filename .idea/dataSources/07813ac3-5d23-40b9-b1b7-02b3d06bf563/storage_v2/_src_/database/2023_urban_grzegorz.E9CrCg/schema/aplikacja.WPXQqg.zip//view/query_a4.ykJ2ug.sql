create view query_a4
            (id_planu, id_jednostki, id_cwiczenia, liczba_serii, liczba_powtorzen, dlugosc_przerwy, ciezar, data) as
SELECT cwiczenie_w_treningu.id_planu,
       cwiczenie_w_treningu.id_jednostki,
       cwiczenie_w_treningu.id_cwiczenia,
       cwiczenie_w_treningu.liczba_serii,
       cwiczenie_w_treningu.liczba_powtorzen,
       cwiczenie_w_treningu.dlugosc_przerwy,
       cwiczenie_w_treningu.ciezar,
       cwiczenie_w_treningu.data
FROM aplikacja.cwiczenie_w_treningu
WHERE cwiczenie_w_treningu.id_jednostki = 2
  AND cwiczenie_w_treningu.id_planu = 10;

comment on view query_a4 is 'Wybór wszystkich ćwiczeń z planu o id=10 o nr id jednostki=2.';

alter table query_a4
    owner to "2023_urban_grzegorz";

