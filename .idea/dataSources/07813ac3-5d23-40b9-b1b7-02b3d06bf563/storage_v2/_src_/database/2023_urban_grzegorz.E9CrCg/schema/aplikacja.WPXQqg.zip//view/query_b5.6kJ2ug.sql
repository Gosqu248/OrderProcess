create view query_b5(id_uzytkownika, nazwa_uzytkownika) as
SELECT u.id       AS id_uzytkownika,
       u.username AS nazwa_uzytkownika
FROM aplikacja.user_data u
         LEFT JOIN aplikacja.plan_treningowy p ON u.id = p.id_uzytkownika
WHERE p.id_planu IS NULL
LIMIT 100;

comment on view query_b5 is 'Wybór 100 użytkowników(id, nazwa), którzy nie wykonali żadnego treningu';

alter table query_b5
    owner to "2023_urban_grzegorz";

