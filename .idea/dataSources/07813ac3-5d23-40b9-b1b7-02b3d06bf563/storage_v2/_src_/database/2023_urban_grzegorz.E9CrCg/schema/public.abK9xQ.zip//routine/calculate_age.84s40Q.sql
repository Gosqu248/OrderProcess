create function calculate_age(birthdate date) returns integer
    language plpgsql
as
$$
DECLARE
    age_in_years integer;
BEGIN
    -- Oblicz wiek na podstawie daty urodzenia
    SELECT EXTRACT(YEAR FROM age(current_date, birthdate))::integer INTO age_in_years;
    RETURN age_in_years;
END;
$$;

alter function calculate_age(date) owner to "2023_urban_grzegorz";

