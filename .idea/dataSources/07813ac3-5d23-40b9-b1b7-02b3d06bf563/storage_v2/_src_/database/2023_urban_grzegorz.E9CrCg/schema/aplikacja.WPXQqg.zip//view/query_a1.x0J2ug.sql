create view query_a1(nazwa_produktu, kalorie) as
SELECT produkt_spozywczy.nazwa_produktu,
       produkt_spozywczy.kalorie
FROM aplikacja.produkt_spozywczy
WHERE produkt_spozywczy.kalorie < 50::numeric;

comment on view query_a1 is 'Produkty spożywcze o kaloriach poniżej 50.';

alter table query_a1
    owner to "2023_urban_grzegorz";

