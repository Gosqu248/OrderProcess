create view kierunki_studiow_stacjonarnych
            (id_kierunku, nazwa_kierunku, liczba_semestrow, stopien_studiow, tytul_zawodowy) as
SELECT kierunki_studiow.id_kierunku,
       kierunki_studiow.nazwa_kierunku,
       kierunki_studiow.liczba_semestrow,
       kierunki_studiow.stopien_studiow,
       kierunki_studiow.tytul_zawodowy
FROM dziekanat.kierunki_studiow
WHERE kierunki_studiow.tryb_studiow::text ~~* 'stacjonarne'::text
ORDER BY kierunki_studiow.nazwa_kierunku;

alter table kierunki_studiow_stacjonarnych
    owner to "2023_urban_grzegorz";

