create view query_b6(id_uzytkownika, nazwa_uzytkownika, nazwa_planu) as
SELECT u.id       AS id_uzytkownika,
       u.username AS nazwa_uzytkownika,
       p.nazwa_planu
FROM aplikacja.user_data u
         JOIN aplikacja.plan_treningowy p ON u.id = p.id_uzytkownika;

comment on view query_b6 is 'Wybór wszystkich użytkowników wraz z nazwami ich planami treningowymi';

alter table query_b6
    owner to "2023_urban_grzegorz";

