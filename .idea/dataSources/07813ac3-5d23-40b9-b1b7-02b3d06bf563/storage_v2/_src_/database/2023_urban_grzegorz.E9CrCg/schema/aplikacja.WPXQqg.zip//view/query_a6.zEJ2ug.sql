create view query_a6(nazwa_planu, opis) as
SELECT plan_treningowy.nazwa_planu,
       plan_treningowy.opis
FROM aplikacja.plan_treningowy
WHERE plan_treningowy.poziom_zaawansowania = 'zaawansowany'::aplikacja."Poziom Zaawansowania";

comment on view query_a6 is 'Wybór wszystkich planów treningowych dla zaawansowanych.';

alter table query_a6
    owner to "2023_urban_grzegorz";

