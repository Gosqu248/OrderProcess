create function c_znajdz_tytul_prowadzacego(p_imie character varying, p_nazwisko character varying)
    returns TABLE(id integer, tytul character varying, stanowisko character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT id_prowadzacego, tytul, stanowisko
    FROM kadry.prowadzacy 
    WHERE imie = p_imie AND nazwisko = p_nazwisko;
END;
$$;

alter function c_znajdz_tytul_prowadzacego(varchar, varchar) owner to "2023_urban_grzegorz";

