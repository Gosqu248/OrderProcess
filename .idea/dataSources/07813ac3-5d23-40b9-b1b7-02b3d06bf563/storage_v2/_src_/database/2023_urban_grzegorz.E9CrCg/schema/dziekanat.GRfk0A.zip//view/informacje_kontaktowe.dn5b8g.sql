create view informacje_kontaktowe ("NR_ALBUMU", "IMIĘ", "NAZWISKO", "TEL. STACJONARNY", "TEL. KOMÓRKOWY", "EMAIL") as
SELECT studenci.nr_albumu           AS "NR_ALBUMU",
       studenci.imie                AS "IMIĘ",
       studenci.nazwisko            AS "NAZWISKO",
       osobiste.telefon_stacjonarny AS "TEL. STACJONARNY",
       osobiste.telefon_komorkowy   AS "TEL. KOMÓRKOWY",
       osobiste.email               AS "EMAIL"
FROM dziekanat.studenci
         JOIN dziekanat.osobiste USING (nr_albumu)
ORDER BY studenci.nazwisko, studenci.imie;

alter table informacje_kontaktowe
    owner to "2023_urban_grzegorz";

