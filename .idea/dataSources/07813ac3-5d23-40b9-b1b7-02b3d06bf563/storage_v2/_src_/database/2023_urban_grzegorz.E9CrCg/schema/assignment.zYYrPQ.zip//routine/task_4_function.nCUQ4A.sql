create function task_4_function() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
   
    IF  NEW.adres_korespondencyjny <> OLD.adres_korespondencyjny THEN
        UPDATE dziekanat.studenci 
        SET adres_korespondencyjny = NEW.adres_korespondencyjny
        WHERE nr_albumu = NEW.nr_albumu;
    END IF;
    
    RETURN NEW;
END;
$$;

comment on function task_4_function() is 'Funkcja sprawdza, czy nastąpiła zmiana w adresie korespondencyjnym studenta i jeśli tak, aktualizuje ten adres w tabeli "studenci" dla tego samego studenta.';

alter function task_4_function() owner to "2023_urban_grzegorz";

