create function get_training_days_by_user(user_id bigint)
    returns TABLE(id_jednostki bigint, nazwa_planu aplikacja."Nazwa Planu", poziom_zaawansowania aplikacja."Poziom Zaawansowania", nr_dnia aplikacja."Numer Dnia", nr_tygodnia bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT jt.id_jednostki, pt.nazwa_planu, pt.poziom_zaawansowania, jt.nr_dnia, jt.nr_tygodnia
    FROM aplikacja.jednostka_treningowa jt
	JOIN aplikacja.plan_treningowy pt ON pt.id_planu = jt.id_planu
    WHERE pt.id_uzytkownika = user_id
    ORDER BY jt.nr_tygodnia, jt.id_jednostki;
END;
$$;

alter function get_training_days_by_user(bigint) owner to "2023_urban_grzegorz";

