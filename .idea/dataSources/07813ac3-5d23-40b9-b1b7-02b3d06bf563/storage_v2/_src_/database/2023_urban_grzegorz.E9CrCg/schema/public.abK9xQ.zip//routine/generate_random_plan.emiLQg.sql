create function generate_random_plan() returns void
    language plpgsql
as
$$
DECLARE
    i INT := 1;
    nazwa_planu_dict "aplikacja"."Nazwa Planu"[] := ARRAY[
        'FBW 3-dniowy', 'FBW 4-dniowy', 'FBW 5-dniowy', 'PPL 3-dniowy', 'PPL 6-dniowy', 'Góra-Dół 4-dniowy', 'Góra-Dół 6-dniowy'
    ];
    opisy TEXT[] := ARRAY[
        'Pełny trening FBW trwający 3 dni w tygodniu.',
        'Rozszerzony trening FBW trwający 4 dni w tygodniu.',
        'Najbardziej zaawansowany trening FBW trwający 5 dni w tygodniu.',
        'Podział treningu na partie: push, pull, legs - trwa 3 dni w tygodniu.',
        'Bardzo intensywny plan treningowy podzielony na 6 dni.',
        'Trening z podziałem na górną i dolną partię ciała, trwający 4 dni w tygodniu.',
        'Zaawansowany plan treningowy z podziałem na górną i dolną partię ciała, trwający 6 dni w tygodniu.'
    ];
    poziom "aplikacja"."Poziom Zaawansowania"[] := ARRAY[
        'początkujący', 'średnio-zaawansowany', 'zaawansowany'
    ];

BEGIN
    WHILE i <= 5000 LOOP
        INSERT INTO aplikacja.plan_treningowy ("id_planu", "nazwa_planu", "opis", "poziom_zaawansowania", "id_uzytkownika")
        VALUES (
            i,
            nazwa_planu_dict[i % 7 + 1], -- Cycle through the array using modulus
            opisy[i % 7 + 1],             -- Cycle through the array using modulus
            poziom[i % 3 + 1],            -- Cycle through the array using modulus
            i
        );
        i := i + 1;
    END LOOP;
END;
$$;

alter function generate_random_plan() owner to "2023_urban_grzegorz";

