create view task_1(id_prowadzacego, data_wyplaty, miesiac, rok, kwota) as
SELECT wyplaty.id_prowadzacego,
       wyplaty.data_wyplaty,
       wyplaty.miesiac,
       wyplaty.rok,
       wyplaty.kwota
FROM kadry.wyplaty
WHERE (wyplaty.id_prowadzacego IN (SELECT prowadzacy.id_prowadzacego
                                   FROM kadry.prowadzacy
                                   WHERE prowadzacy.imie = 'Jadwiga'::bpchar
                                     AND prowadzacy.nazwisko::text = 'Jawska'::text))
ORDER BY wyplaty.data_wyplaty DESC;

comment on view task_1 is 'Utwórz zapytanie wyszukujące wszystkie wypłaty dla prowadzącego: Jadwiga Jawska. 
Wyświetl następujące atrybuty: ID prowadzącego, Date wypłaty, Miesiąc, Rok oraz Kwote.';

alter table task_1
    owner to "2023_urban_grzegorz";

