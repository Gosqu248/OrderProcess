create function get_product_by_calories(p_max_calories numeric)
    returns TABLE(product_name character varying, calories numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT "nazwa_produktu", "kalorie"
    FROM aplikacja.produkt_spozywczy
    WHERE "kalorie" = p_max_calories;
END;
$$;

alter function get_product_by_calories(numeric) owner to "2023_urban_grzegorz";

