create function znajdz_prowadzacego(p_imie character varying, p_nazwisko character varying)
    returns TABLE(id integer, tytul character varying, stanowisko character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT p.id, p.tytul, k.stanowisko
    FROM kadry.prowadzacy p
    JOIN kadry.jednostki_organizacyjne k ON p.id_jednostki = k.id
    WHERE p.imie = p_imie AND p.nazwisko = p_nazwisko;
END;
$$;

alter function znajdz_prowadzacego(varchar, varchar) owner to "2023_urban_grzegorz";

