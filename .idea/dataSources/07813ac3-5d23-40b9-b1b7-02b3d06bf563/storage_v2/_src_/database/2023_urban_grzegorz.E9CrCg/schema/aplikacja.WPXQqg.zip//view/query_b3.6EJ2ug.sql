create view query_b3 (nazwa_planu, id_jednostki, nazwa_cwiczenia, liczba_serii, liczba_powtorzen, kategoria) as
SELECT pt.nazwa_planu,
       cwt.id_jednostki,
       cw.nazwa_cwiczenia,
       cwt.liczba_serii,
       cwt.liczba_powtorzen,
       cw.kategoria
FROM aplikacja.plan_treningowy pt
         JOIN aplikacja.cwiczenie_w_treningu cwt ON pt.id_planu = cwt.id_planu
         JOIN aplikacja.cwiczenie cw ON cwt.id_cwiczenia = cw.id_cwiczenia
WHERE pt.id_uzytkownika = 10
ORDER BY cwt.id_jednostki;

comment on view query_b3 is 'Wybór wszystkich ćwiczeń w danym planie treningowym uzytkownika o id=10 i posortowane rosnąco według id_jednostki.';

alter table query_b3
    owner to "2023_urban_grzegorz";

