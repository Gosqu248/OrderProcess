create materialized view physical_view_c5 as
SELECT produkt_spozywczy.nazwa_produktu,
       produkt_spozywczy.weglowodany
FROM aplikacja.produkt_spozywczy
ORDER BY produkt_spozywczy.weglowodany DESC
LIMIT 75;

alter materialized view physical_view_c5 owner to "2023_urban_grzegorz";

