create function after_insert_nutrition() returns trigger
    language plpgsql
as
$$
BEGIN
    
    UPDATE aplikacja.odzywianie SET wykonany = true WHERE "id_posilku" = NEW.id_posilku AND "id_uzytkownika" = NEW.id_uzytkownika;
    RETURN NEW;
END;
$$;

alter function after_insert_nutrition() owner to "2023_urban_grzegorz";

