create function get_users_by_plan_level(p_plan_level aplikacja."Poziom Zaawansowania")
    returns TABLE(user_id bigint, username text, plan_name text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT u."id_uzytkownika", u."nazwa_uzytkownika", p."nazwa_planu"
    FROM aplikacja.uzytkownik u
    JOIN aplikacja.plan_treningowy p ON u."id_uzytkownika" = p."id_uzytkownika"
    WHERE p."poziom_zaawansowania" = p_plan_level::aplikacja."Poziom Zaawansowania";
END;
$$;

alter function get_users_by_plan_level(aplikacja."Poziom Zaawansowania") owner to "2023_urban_grzegorz";

