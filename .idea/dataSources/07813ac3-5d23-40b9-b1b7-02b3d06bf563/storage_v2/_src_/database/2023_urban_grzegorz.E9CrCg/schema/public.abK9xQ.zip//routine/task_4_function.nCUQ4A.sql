create function task_4_function() returns trigger
    language plpgsql
as
$$
DECLARE
    v_nr_albumu INT;
    v_srednia_ocen NUMERIC;
BEGIN
    -- Pobierz nr_albumu studenta na podstawie dodanej oceny
    v_nr_albumu := NEW.nr_albumu;
    
    -- Oblicz średnią ocen studenta
    SELECT AVG(ocena) INTO v_srednia_ocen
    FROM dziekanat.oceny
    WHERE nr_albumu = v_nr_albumu;
    
    -- Zaktualizuj informacje o średniej ocen w tabeli "studenci"
    UPDATE dziekanat.studenci
    SET srednia_ocen = v_srednia_ocen
    WHERE nr_albumu = v_nr_albumu;
    
    RETURN NEW;
END;
$$;

alter function task_4_function() owner to "2023_urban_grzegorz";

