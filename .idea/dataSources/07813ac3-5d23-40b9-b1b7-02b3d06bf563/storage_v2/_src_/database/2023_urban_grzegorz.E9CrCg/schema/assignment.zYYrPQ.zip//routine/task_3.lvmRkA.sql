create function task_3(p_imie character varying, p_nazwisko character varying) returns character varying
    language plpgsql
as
$$
DECLARE
    v_tytul VARCHAR;
BEGIN
    SELECT tytul INTO v_tytul
    FROM kadry.prowadzacy
    WHERE imie = p_imie AND nazwisko = p_nazwisko;
    
    IF FOUND THEN
        RETURN v_tytul;
    ELSE
        RETURN 'Brak informacji o prowadzącym.';
    END IF;
END;
$$;

comment on function task_3(varchar, varchar) is 'Utwórz w języku PL/pgSQL funkcję wyznaczającą tytuł prowadzącego. 
Argumentami wywoływania powinny być: Imie, Nazwisko prowadzacego.';

alter function task_3(varchar, varchar) owner to "2023_urban_grzegorz";

