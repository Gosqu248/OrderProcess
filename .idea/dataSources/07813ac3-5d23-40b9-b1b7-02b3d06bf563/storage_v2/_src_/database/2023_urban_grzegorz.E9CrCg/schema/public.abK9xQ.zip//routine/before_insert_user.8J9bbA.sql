create function before_insert_user() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM aplikacja.uzytkownik WHERE id_uzytkownika = NEW.id_uzytkownika) THEN
        RAISE EXCEPTION 'ID % jest już używany.', NEW.id_uzytkownika;
    END IF;
	
    IF EXISTS (SELECT 1 FROM aplikacja.uzytkownik WHERE email = NEW.email) THEN
        RAISE EXCEPTION 'Email % jest już używany.', NEW.email;
    END IF;

    
    IF EXISTS (SELECT 1 FROM aplikacja.uzytkownik WHERE nazwa_uzytkownika = NEW.nazwa_uzytkownika) THEN
        RAISE EXCEPTION 'Nazwa użytkownika % jest już używana.', NEW.nazwa_uzytkownika;
    END IF;
	
	

    RETURN NEW;
END;
$$;

alter function before_insert_user() owner to "2023_urban_grzegorz";

