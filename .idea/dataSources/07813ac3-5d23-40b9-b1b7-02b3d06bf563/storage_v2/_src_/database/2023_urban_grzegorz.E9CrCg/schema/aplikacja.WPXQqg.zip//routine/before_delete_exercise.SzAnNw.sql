create function before_delete_exercise() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Sprawdź, czy ćwiczenie jest używane w jakimkolwiek planie treningowym
    IF EXISTS (SELECT 1 FROM aplikacja.cwiczenie_w_treningu WHERE id_cwiczenia = OLD.id_cwiczenia) THEN
        RAISE EXCEPTION 'Nie można usunąć ćwiczenia, które jest używane w planie treningowym.';
    END IF;

    RETURN OLD;
END;
$$;

alter function before_delete_exercise() owner to "2023_urban_grzegorz";

