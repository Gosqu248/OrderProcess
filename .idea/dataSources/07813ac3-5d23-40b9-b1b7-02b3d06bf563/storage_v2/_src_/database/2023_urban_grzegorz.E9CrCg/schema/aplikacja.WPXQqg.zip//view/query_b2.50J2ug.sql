create view query_b2(id_uzytkownika, nazwa_uzytkownika, nazwa_planu) as
WITH usertraining AS (SELECT u.id       AS id_uzytkownika,
                             u.username AS nazwa_uzytkownika,
                             p.nazwa_planu
                      FROM aplikacja.user_data u
                               JOIN aplikacja.plan_treningowy p ON u.id = p.id_uzytkownika)
SELECT usertraining.id_uzytkownika,
       usertraining.nazwa_uzytkownika,
       usertraining.nazwa_planu
FROM usertraining
WHERE usertraining.nazwa_planu = 'Góra-Dół 6-dniowy'::aplikacja."Nazwa Planu"
LIMIT 20;

comment on view query_b2 is 'Znajdź 20 pierwszych użytkowników, którzy mają plan o nazwie "Góra-Dół 6-dniowy".';

alter table query_b2
    owner to "2023_urban_grzegorz";

