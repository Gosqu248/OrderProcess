create function funkcja1() returns trigger
    language plpgsql
as
$$
DECLARE
    v_student_id INT;
    v_srednia_ocen NUMERIC;
BEGIN
    -- Pobierz ID studenta na podstawie dodanej oceny
    v_student_id := NEW.id_studenta;
    
    -- Oblicz średnią ocen studenta
    SELECT AVG(ocena) INTO v_srednia_ocen
    FROM dziekanat.oceny
    WHERE id_studenta = v_student_id;
    
    -- Zaktualizuj informacje o średniej ocen w tabeli "studenci"
    UPDATE dziekanat.studenci
    SET srednia_ocen = v_srednia_ocen
    WHERE id = v_student_id;
    
    RETURN NEW;
END;
$$;

alter function funkcja1() owner to "2023_urban_grzegorz";

