create materialized view physical_view_c4 as
SELECT dailycalories.id_uzytkownika,
       round(avg(dailycalories.calories_consumed), 0) AS avg_calories_per_day
FROM (SELECT o.id_uzytkownika,
             o.data,
             sum(ps.kalorie) AS calories_consumed
      FROM aplikacja.odzywianie o
               JOIN aplikacja.produkt_w_posilku pp ON o.id_posilku = pp.id_posilku
               JOIN aplikacja.produkt_spozywczy ps ON pp.id_produktu = ps.id_produktu
      GROUP BY o.id_uzytkownika, o.data) dailycalories
GROUP BY dailycalories.id_uzytkownika;

alter materialized view physical_view_c4 owner to "2023_urban_grzegorz";

