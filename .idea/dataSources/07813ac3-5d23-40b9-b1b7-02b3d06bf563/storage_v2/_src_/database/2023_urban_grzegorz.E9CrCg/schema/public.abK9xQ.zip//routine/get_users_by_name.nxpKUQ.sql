create function get_users_by_name(p_imie character varying)
    returns TABLE(id_uzytkownika bigint, nazwa_uzytkownika text, email character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT "id_uzytkownika", "imie", "nazwisko"
    FROM aplikacja.uzytkownik
    WHERE "imie" = p_imie;
END;
$$;

alter function get_users_by_name(varchar) owner to "2023_urban_grzegorz";

