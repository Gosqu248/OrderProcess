create function task4() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Sprawdzenie, czy wystąpiła operacja INSERT w tabeli "przedmioty"
    IF TG_OP = 'INSERT' THEN
        -- Pobranie identyfikatora prowadzącego z nowego rekordu
        DECLARE
            v_id_prowadzacego INT := NEW.id_prowadzacego;
        BEGIN
            -- Zwiększenie liczby kursów prowadzonych przez prowadzącego
            UPDATE kadry.prowadzacy
            SET liczba_kursow = liczba_kursow + 1
            WHERE id_prowadzacego = v_id_prowadzacego;
        END;
    END IF;

    RETURN NEW;
END;
$$;

alter function task4() owner to "2023_urban_grzegorz";

