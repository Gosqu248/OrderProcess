create function generate_random_odzywianie() returns void
    language plpgsql
as
$$
DECLARE
    i INT := 1;

	daty Date [] := Array[
'2023-12-07', '2023-12-08', '2023-12-09', '2023-12-10', '2023-12-11', '2023-12-12', '2023-12-13', '2023-12-14', '2023-12-15', '2023-12-16', '2023-12-17', '2023-12-18', '2023-12-19', '2023-12-20', '2023-12-21', '2023-12-22', '2023-12-23', '2023-12-24', '2023-12-25', '2023-12-26', '2023-12-27', '2023-12-28', '2023-12-29', '2023-12-30', '2023-12-31', '2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-06', '2024-01-07', '2024-01-08', '2024-01-09', '2024-01-10', '2024-01-11', '2024-01-12', '2024-01-13', '2024-01-14', '2024-01-15', '2024-01-16', '2024-01-17', '2024-01-18', '2024-01-19', '2024-01-20', '2024-01-21', '2024-01-22', '2024-01-23', '2024-01-24', '2024-01-25'
	]; 
		
	

BEGIN
    WHILE i <= 1000 LOOP
        -- Inkrementacja j dla każdego i podzielonego przez 4
      
        -- Wstawianie danych do tabeli
        INSERT INTO aplikacja.odzywianie ("id_posilku", "id_uzytkownika", "data", "wykonany")
        VALUES (
            i,
            CASE
                WHEN i <= 50 THEN 1
                WHEN i <= 100 THEN 2
                WHEN i <= 150 THEN 3
                WHEN i <= 200 THEN 4
                WHEN i <= 250 THEN 5
				WHEN i <= 300 THEN 6
                WHEN i <= 350 THEN 7
                WHEN i <= 400 THEN 8
                WHEN i <= 450 THEN 9
				WHEN i <= 500 THEN 10
                WHEN i <= 550 THEN 11
                WHEN i <= 600 THEN 12
                WHEN i <= 650 THEN 13
				WHEN i <= 700 THEN 14
                WHEN i <= 750 THEN 15
				WHEN i <= 800 THEN 16
                WHEN i <= 850 THEN 17
                WHEN i <= 900 THEN 18
                WHEN i <= 950 THEN 19
			    WHEN i <= 1000 THEN 20

			
            END,
            daty[ROUND(1 + (i - 1) / 20)],
            'true'
        );

        i := i + 1;
		
    END LOOP;
END;
$$;

alter function generate_random_odzywianie() owner to "2023_urban_grzegorz";

