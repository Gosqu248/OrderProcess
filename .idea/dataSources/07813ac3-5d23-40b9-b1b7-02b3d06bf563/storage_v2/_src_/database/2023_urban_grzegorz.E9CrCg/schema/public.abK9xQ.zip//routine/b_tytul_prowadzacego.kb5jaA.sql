create function b_tytul_prowadzacego(p_imie character varying, p_nazwisko character varying)
    returns TABLE(id integer, tytul character varying, stanowisko character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT p.id, p.tytul, j.stanowisko
    FROM kadry.prowadzacy p
    WHERE p.imie = p_imie AND p.nazwisko = p_nazwisko;
END;
$$;

alter function b_tytul_prowadzacego(varchar, varchar) owner to "2023_urban_grzegorz";

