create view query_a5(nazwa_cwiczenia, kategoria) as
SELECT cwiczenie.nazwa_cwiczenia,
       cwiczenie.kategoria
FROM aplikacja.cwiczenie;

comment on view query_a5 is 'Lista wszystkich ćwiczeń wraz z ich kategoriami.';

alter table query_a5
    owner to "2023_urban_grzegorz";

