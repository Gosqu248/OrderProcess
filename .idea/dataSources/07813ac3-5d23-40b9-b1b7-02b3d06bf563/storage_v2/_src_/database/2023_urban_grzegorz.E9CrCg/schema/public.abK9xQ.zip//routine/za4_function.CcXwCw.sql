create function za4_function() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.ocena > 5 THEN
        RAISE EXCEPTION 'Ocena nie może przekraczać 5.';
    END IF;
    RETURN NEW;
END;
$$;

alter function za4_function() owner to "2023_urban_grzegorz";

