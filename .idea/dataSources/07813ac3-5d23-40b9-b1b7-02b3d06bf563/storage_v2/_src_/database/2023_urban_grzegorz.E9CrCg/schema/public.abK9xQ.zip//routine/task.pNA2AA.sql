create function task() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Sprawdzenie, czy wystąpiła operacja INSERT w tabeli "przedmioty"
    IF TG_OP = 'INSERT' THEN
        -- Pobranie identyfikatora prowadzącego z nowego rekordu
        DECLARE
            v_prowadzacy_id INT := NEW.prowadzacy_id;
        BEGIN
            -- Zwiększenie liczby kursów prowadzonych przez prowadzącego
            UPDATE kadry.prowadzacy
            SET liczba_kursow = liczba_kursow + 1
            WHERE id_prowadzacego = v_prowadzacy_id;
        END;
    END IF;

    RETURN NEW;
END;
$$;

alter function task() owner to "2023_urban_grzegorz";

