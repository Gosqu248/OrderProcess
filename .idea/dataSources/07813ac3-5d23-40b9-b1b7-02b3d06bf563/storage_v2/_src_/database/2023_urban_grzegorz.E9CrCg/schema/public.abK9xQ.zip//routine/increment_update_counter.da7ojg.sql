create function increment_update_counter() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    -- Inkrementuj sekwencję po operacji UPDATE
    SELECT nextval('update_counter_seq');
  END IF;
  RETURN NEW;
END;
$$;

alter function increment_update_counter() owner to "2023_urban_grzegorz";

