create view query_b7(id_uzytkownika, data, id_posilku, nazwa_produktu, kalorie) as
SELECT o.id_uzytkownika,
       o.data,
       pp.id_posilku,
       ps.nazwa_produktu,
       ps.kalorie
FROM aplikacja.odzywianie o
         JOIN aplikacja.produkt_w_posilku pp ON o.id_posilku = pp.id_posilku
         JOIN aplikacja.produkt_spozywczy ps ON pp.id_produktu = ps.id_produktu
WHERE o.id_uzytkownika = 2
  AND pp.id_posilku = 62;

comment on view query_b7 is 'Wybór wszystkich produktów które użytkownik o id=2 zjadł w posiłku o id=62';

alter table query_b7
    owner to "2023_urban_grzegorz";

