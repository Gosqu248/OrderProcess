create function query_measurement(query text DEFAULT ''::text, n integer DEFAULT 100) returns interval
    stable
    language plpgsql
as
$$
DECLARE
	i integer;
	start_time timestamp;
	end_time timestamp;
	duration interval;
BEGIN
	start_time := clock_timestamp();
	FOR i IN 1 .. $2 LOOP
		EXECUTE $1;
	END LOOP;
	end_time := clock_timestamp();

	duration := end_time - start_time;
	RAISE NOTICE 'Duration = %', duration;
END
$$;

alter function query_measurement(text, integer) owner to "2023_urban_grzegorz";

