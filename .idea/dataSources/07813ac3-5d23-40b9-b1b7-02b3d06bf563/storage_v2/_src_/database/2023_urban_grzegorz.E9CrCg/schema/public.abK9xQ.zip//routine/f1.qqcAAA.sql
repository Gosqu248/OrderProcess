create function f1() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Sprawdź, czy nastąpiły zmiany w danych osobowych studenta
    IF NEW.imie <> OLD.imie OR NEW.nazwisko <> OLD.nazwisko OR NEW.adres <> OLD.adres THEN
        -- Aktualizuj adres korespondencyjny studenta
        UPDATE adres_korespondencyjny
        SET adres = NEW.adres
        WHERE student_id = NEW.id;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function f1() owner to "2023_urban_grzegorz";

