create function generate_random_porada() returns void
    language plpgsql
as
$$
DECLARE
    i INT := 1;
	
	tytuly TEXT[] := Array [
		'Jak zacząć z siłownią?',
		'Trening na siłowni dla początkujących – o czym jeszcze pamiętać?',
		'Podsumowanie',
		'Zacznij od obliczenia swojego zapotrzebowania energetycznego',
		'Postaw na zbilansowaną dietę',
		'Rusz się !',
		'Jaka dieta ma wpływ na wzrost wzrostu?',
		'Dieta i odpowiednia ilość kalorii',
		'Nie zapomnij o śnie'
	];
	
    tresci TEXT[] := ARRAY[
        'Zanim wybierzesz się na siłownię, zastanów się, co dokładnie chcesz osiągnąć dzięki treningom. Czy szukasz sposobu, by poprawić swoje samopoczucie i ogólny stan zdrowia? Zależy Ci na lepszej kondycji? A może masz konkretne plany wobec swojej sylwetki? Ważne, by cel, który sobie postawisz, był realny – dostosowany do Twoich możliwości. Jeśli założysz, że chcesz schudnąć kilkanaście kilogramów lub przygotować się do maratonu w ciągu miesiąca, możesz mocno się rozczarować.',
		'Przed wizytą na siłowni zadbaj o odpowiednie akcesoria. Najważniejsze są komfortowe, oddychające ubrania sportowe, w których bez problemu wykonasz różne ćwiczenia. Obuwie powinno być stabilne, przewiewne i przede wszystkim wygodne – dzięki temu łatwiej będzie Ci zachować równowagę, unikniesz odcisków, obtarć, a Twoje stopy nie będą nadmiernie się pocić. Pamiętaj też, by zabrać ze sobą ręcznik i wodę.',
		'Początki na siłowni nie należą do łatwych. Aby nie zniechęcić się do aktywności fizycznej, warto pamiętać o kilku podstawowych zasadach:
		postaw sobie cel, który jesteś w stanie zrealizować,
		trenuj regularnie,
		stopniowo zwiększaj intensywność ćwiczeń,
		w razie wątpliwości skorzystaj ze wsparcia trenera.
		Dzięki temu sport stanie się dla ciebie przyjemnością, będzie bezpieczny i przyniesie oczekiwane rezultaty!',
		'Znajomość własnego zapotrzebowania kalorycznego, czyli BMR jest istotna, by utrzymywać podstawowe funkcje naszego organizmu.

		- Do diety powinniśmy podchodzić przede wszystkim zdroworozsądkowo - liczba 1000 kalorii dla dorosłej, uprawiającej sport osoby to zdecydowanie zbyt mało. Konsekwencjami wynikającymi ze stosowania tak restrykcyjnego sposobu odżywiania mogą być m.in. spowolnienie metabolizmu, efekt jojo, wzmożone zmęczenie, spadek masy mięśniowej, zaburzenia hormonalne czy zaburzenia cyklu miesiączkowego - tłumaczy Patrycja Zabrzeska, psychodietetyk, trener personalny, dietetyk w Rukola Catering Dietetyczny - Dietę zacznijmy od poznania dziennego zapotrzebowania kalorycznego. Możemy do tego użyć specjalnego kalkulatora, w którym podamy nasz cel, wagę, wzrost, wiek oraz określimy naszą aktywność fizyczną w ciągu dnia - dodaje ekspertka.',		
			'Dieta mająca na celu spalenie tłuszczu zakłada wyeliminowanie z naszego menu kalorycznych potraw, które są bogate w duże ilości cukrów prostych i niskiej jakości tłuszcze. Powinniśmy zastąpić je produktami białkowymi, wysokobłonnikowymi, owocami, warzywami oraz ziołami.

		Jeżeli zależy nam na utracie tkanki tłuszczowej musimy pamiętać, aby posiłki, które spożywamy, miały określoną liczbę kalorii - niższą od naszego zapotrzebowania kalorycznego. Ponadto powinniśmy zachować odpowiednią proporcję węglowodanów, tłuszczu i białka.',    	
			'Istotną składową redukcji tkanki tłuszczowej jest dodanie, bądź zwiększenie naszej aktywności fizycznej. Jest ona niezwykle ważna, gdyż nie tylko pozwoli nam zachować mobilność i kondycję, ale też utrzymać zdrowy styl życia. Należy jednak pamiętać, że treningi powinny być wprowadzane w miarę rozsądku i być połączone z odpowiednią regeneracją organizmu, w tym ze snem.

		Jedną z polecanych form aktywności podczas redukcji są treningi cardio, do których zaliczamy m.in. spacery, bieganie, jazdę na rowerze czy pływanie. W trakcie wykonywania tych ćwiczeń zwiększa się zapotrzebowanie na energię, którą organizm pobiera ze zgromadzonych zapasów tkanki tłuszczowej. Cardio warto uzupełnić o ćwiczenia siłowe, które wpłyną na rozbudowę masy mięśniowej.

		- Aby nasze treningi przyniosły zamierzony efekt, powinniśmy odpowiednio dobrać czas ich trwania, częstotliwość oraz intensywność ćwiczeń dostosowaną do naszych możliwości. Niestety wiele osób na początku popełnia błąd i zapomina o niezbędnej dla naszego organizmu regeneracji - komentuje ekspertka',
			'To oczywiste, że nie jesteśmy tym, co jemy. Jesteśmy tym, co możemy wchłonąć, ale też tym, czego nie potrafimy zutylizować. Trzeba jednak przyznać, że zdrowa dieta i odpowiednie odżywienie, to kamień węgielny wszystkiego, co dobre w naszych ciałach. Jeśli chcesz zwiększyć swój wzrost, no dobra, powiem to, a więc jeśli chcesz urosnąć, potrzebujesz zaplanować dietę, która może pobudzać wzrost hormonów w organizmie i uzupełniać utracone komórki.

		Zadbaj szczególnie o podaż witamin z grupy B, witaminy D oczywiście w protokole z K2, fosforu, cynku, oraz wapnia. Nie zapomnij też o nawadnianiu!

		Witamin D3+K2
		Mariaż witamin D3+K2 pomaga kościom absorbować wapń i dobrze wykorzystać magnez. Przyczynia się to do wzmocnienia kości i wspomaga ich rozwój. Nie tylko przyjmij wysokiej jakości witaminy, ale także i przede wszystkim absorbuj witaminę D ze słońca.

		Wapń
		Kości potrzebują wapnia aby rozwijać się i rosnąć.

		Bogate w wapń są na przykład:
		nasiona chia
		sezam
		migdały
		biała fasola
		rabarbar
		szpinak
		jarmuż
		komosa
		Cynk
		Warto przy okazji zwiększyć konsumpcję cynku jedząc szparagi, groszek, arbuzy, dynie, cukinie, surową gorzką czekoladę, a także jajka i ostrygi.',
			'Dieta na masę charakteryzuje się tym, że posiada dodatni bilans kaloryczny. Niestety wiele osób wpada ze skrajności w skrajność. Osobom trenującym zależeć powinno na wzroście wyłącznie beztłuszczowej masy ciała.

		W tym celu należy stopniowo i powoli zwiększać dzienną podaż kalorii. Ektomorficy muszą spożywać zdecydowanie więcej pożywienia aby ich organizm rozpoczął procesy anaboliczne. Zjedzenie 4 czy 5 tysięcy kalorii dziennie może stanowić poważne wyzwanie.',
			'Sen jest bardzo ważny dla odpowiedniego wydzielania i funkcjonowania hormonu wzrostu. Pamiętaj o tym aby spać 8 godzin dziennie.'
	];
	
	kateg "Kategoria"[] := Array [
			'początkujący','początkujący','początkujący', 'chudnięcie', 'chudnięcie', 'chudnięcie', 'budowanie masy mięśniowej',  'budowanie masy mięśniowej', 'budowanie masy mięśniowej'
		];	
	

  

BEGIN
    WHILE i <= 9 LOOP
        INSERT INTO aplikacja.porada_treningowa ("id_porady", "tytul", "tresc", "kategoria")
        VALUES (
            i,
            tytuly[i],
			tresci[i],
			kateg[i]
        );
        i := i + 1;
    END LOOP;
END;
$$;

alter function generate_random_porada() owner to "2023_urban_grzegorz";

