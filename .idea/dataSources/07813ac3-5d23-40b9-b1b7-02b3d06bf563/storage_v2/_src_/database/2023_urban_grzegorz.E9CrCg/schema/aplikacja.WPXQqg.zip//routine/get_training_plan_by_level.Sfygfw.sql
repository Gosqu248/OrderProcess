create function get_training_plan_by_level(plan_level aplikacja."Poziom Zaawansowania")
    returns TABLE(id_planu bigint, nazwa_planu aplikacja."Nazwa Planu", opis text, poziom_zaawansowania aplikacja."Poziom Zaawansowania", id_uzytkownika bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT *
    FROM aplikacja.plan_treningowy pt
    WHERE pt.poziom_zaawansowania = get_training_plan_by_level.plan_level
	LIMIT 20;
END;
$$;

alter function get_training_plan_by_level(aplikacja."Poziom Zaawansowania") owner to "2023_urban_grzegorz";

