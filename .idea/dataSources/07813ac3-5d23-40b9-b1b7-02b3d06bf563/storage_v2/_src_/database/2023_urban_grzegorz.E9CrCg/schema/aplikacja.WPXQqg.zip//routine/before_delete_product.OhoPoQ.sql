create function before_delete_product() returns trigger
    language plpgsql
as
$$
BEGIN
    
    IF EXISTS (SELECT 1 FROM aplikacja.produkt_w_posilku WHERE id_produktu = OLD.id_produktu) THEN
        RAISE EXCEPTION 'Nie można usunąć produktu %, ponieważ jest używany w którymkolwiek posiłku.', OLD.nazwa_produktu;
    END IF;

    RETURN OLD;
END;
$$;

alter function before_delete_product() owner to "2023_urban_grzegorz";

