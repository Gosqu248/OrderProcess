create function increment_update_count() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    UPDATE update_sequence
    SET update_count = update_count + 1
    WHERE sequence_name = 'kadry.wyplaty';
  END IF;
  RETURN NEW;
END;
$$;

alter function increment_update_count() owner to "2023_urban_grzegorz";

