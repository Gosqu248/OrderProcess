create function generate_random_password(length integer) returns text
    language plpgsql
as
$$
DECLARE
    characters text := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    password text := '';
    i integer;
BEGIN
    IF length <= 0 THEN
        RAISE EXCEPTION 'Długość hasła musi być dodatnia.';
    END IF;

    -- Wygeneruj losowe hasło o zadanej długości
    FOR i IN 1..length LOOP
        password := password || substr(characters, floor(random() * length(characters) + 1)::integer, 1);
    END LOOP;

    RETURN password;
END;
$$;

alter function generate_random_password(integer) owner to "2023_urban_grzegorz";

