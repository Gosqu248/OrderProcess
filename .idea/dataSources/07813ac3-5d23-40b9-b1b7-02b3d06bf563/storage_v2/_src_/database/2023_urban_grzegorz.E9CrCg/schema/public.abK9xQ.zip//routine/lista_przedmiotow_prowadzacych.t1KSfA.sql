create function lista_przedmiotow_prowadzacych(id_prowadzacego integer)
    returns TABLE(nazwa_przedmiotu character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT p.nazwa_przedmiotu
    FROM dziekanat.przedmioty p
    JOIN kadry.prowadzacy pr ON p.id_prowadzacego = pr.id_prowadzacego
    WHERE pr.id_prowadzacego = p.id_prowadzacego;
END;
$$;

alter function lista_przedmiotow_prowadzacych(integer) owner to "2023_urban_grzegorz";

