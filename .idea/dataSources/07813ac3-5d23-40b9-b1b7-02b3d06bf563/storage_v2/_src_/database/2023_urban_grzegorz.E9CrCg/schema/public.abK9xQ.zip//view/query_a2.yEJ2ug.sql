create view query_a2(tytul, tresc) as
SELECT porada_treningowa.tytul,
       porada_treningowa.tresc
FROM aplikacja.porada_treningowa
WHERE porada_treningowa.kategoria = 'chudnięcie'::"Kategoria";

comment on view query_a2 is 'Porady treningowe na temat chudnięcia.';

alter table query_a2
    owner to "2023_urban_grzegorz";

