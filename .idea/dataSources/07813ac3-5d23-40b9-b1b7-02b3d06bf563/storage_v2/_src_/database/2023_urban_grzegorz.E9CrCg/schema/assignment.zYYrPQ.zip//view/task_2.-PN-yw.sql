create view task_2(nazwa_przedmiotu, srednia) as
SELECT p.nazwa_przedmiotu,
       round(avg(o.ocena::numeric), 2) AS srednia
FROM dziekanat.przedmioty p
         JOIN dziekanat.oceny o ON p.id_przedmiotu = o.id_przedmiotu
GROUP BY p.nazwa_przedmiotu;

comment on view task_2 is 'Wykorzystując złączenie tabel oraz agregacje, utwórz zapytanie, które wyświetli średnią ocene dla każdego przedmiotu.
Wyświetl: Nazwe przedmiotu oraz Średnia. Zaokrąglij średnią do 2 miejsc po przecinku oraz sortuj weddług nazwy przedmiotu.';

alter table task_2
    owner to "2023_urban_grzegorz";

