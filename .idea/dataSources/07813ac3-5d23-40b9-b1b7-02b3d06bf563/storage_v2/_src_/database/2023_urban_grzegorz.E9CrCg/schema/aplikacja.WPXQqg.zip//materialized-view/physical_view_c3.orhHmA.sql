create materialized view physical_view_c3 as
SELECT o.id_uzytkownika,
       o.data,
       pp.id_posilku,
       ps.nazwa_produktu,
       ps.kalorie
FROM aplikacja.odzywianie o
         JOIN aplikacja.produkt_w_posilku pp ON o.id_posilku = pp.id_posilku
         JOIN aplikacja.produkt_spozywczy ps ON pp.id_produktu = ps.id_produktu
WHERE o.id_uzytkownika = 2
  AND pp.id_posilku = 62;

alter materialized view physical_view_c3 owner to "2023_urban_grzegorz";

