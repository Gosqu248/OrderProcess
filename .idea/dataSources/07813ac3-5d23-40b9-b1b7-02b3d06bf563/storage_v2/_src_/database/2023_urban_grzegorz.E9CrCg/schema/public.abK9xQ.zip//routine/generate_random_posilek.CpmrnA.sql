create function generate_random_posilek() returns void
    language plpgsql
as
$$
DECLARE
    i INT := 500;
	
	nazwy TEXT[] := Array [
		'śniadanie', 'brunch', 'obiad', 'kolacja'
	];

BEGIN
    WHILE i <= 1000 LOOP
        INSERT INTO aplikacja.posilek ("id_posilku", "nazwa_posilku")
        VALUES (
            i,
			nazwy[i%4 +1]
        );
        i := i + 1;
    END LOOP;
END;
$$;

alter function generate_random_posilek() owner to "2023_urban_grzegorz";

