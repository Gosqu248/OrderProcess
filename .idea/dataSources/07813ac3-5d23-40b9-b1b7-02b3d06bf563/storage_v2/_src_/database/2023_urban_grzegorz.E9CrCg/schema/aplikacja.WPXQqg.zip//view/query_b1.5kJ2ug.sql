create view query_b1(id_uzytkownika, data, suma_kalorii) as
WITH caloriesconsumed AS (SELECT o.id_uzytkownika,
                                 o.data,
                                 sum(ps.kalorie) AS suma_kalorii
                          FROM aplikacja.odzywianie o
                                   JOIN aplikacja.produkt_w_posilku pp ON o.id_posilku = pp.id_posilku
                                   JOIN aplikacja.produkt_spozywczy ps ON pp.id_produktu = ps.id_produktu
                          GROUP BY o.id_uzytkownika, o.data)
SELECT caloriesconsumed.id_uzytkownika,
       caloriesconsumed.data,
       caloriesconsumed.suma_kalorii
FROM caloriesconsumed
WHERE caloriesconsumed.id_uzytkownika = 1
  AND caloriesconsumed.suma_kalorii > 3500::numeric;

comment on view query_b1 is 'Suma spożycia kalorii przez użytkownika w danym dniu i znajdz dni w których użytkownik o id=1 zjadł więcej niż 3500 kalorii.';

alter table query_b1
    owner to "2023_urban_grzegorz";

