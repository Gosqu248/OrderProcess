create function calculate_bmi(weight_kg numeric, height_m numeric) returns numeric
    language plpgsql
as
$$
DECLARE
    bmi numeric;
BEGIN
    IF weight_kg <= 0 OR height_m <= 0 THEN
        RAISE EXCEPTION 'Waga i wzrost muszą być dodatnie.';
    END IF;

    -- Oblicz BMI: masa ciała / (wzrost * wzrost)
    bmi := ROUND((weight_kg / (height_m * height_m)),2);

    RETURN bmi;
END;
$$;

alter function calculate_bmi(numeric, numeric) owner to "2023_urban_grzegorz";

