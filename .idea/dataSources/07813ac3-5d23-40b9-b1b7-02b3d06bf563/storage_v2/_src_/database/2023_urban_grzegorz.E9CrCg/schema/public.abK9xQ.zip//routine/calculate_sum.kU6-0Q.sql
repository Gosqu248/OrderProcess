create function calculate_sum(a integer, b integer) returns integer
    language plpgsql
as
$$
DECLARE
    result INTEGER;
BEGIN
    result := a + b;
    RETURN result;
END;
$$;

alter function calculate_sum(integer, integer) owner to "2023_urban_grzegorz";

