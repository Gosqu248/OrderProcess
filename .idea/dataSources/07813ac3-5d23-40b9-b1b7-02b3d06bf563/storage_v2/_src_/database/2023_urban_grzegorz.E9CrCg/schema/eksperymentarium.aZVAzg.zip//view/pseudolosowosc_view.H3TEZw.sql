create view pseudolosowosc_view(sum) as
SELECT sum(((round(i.i::double precision * random())::integer % 2) = 0)::integer) AS sum
FROM generate_series(1, 5000, 1) i(i);

alter table pseudolosowosc_view
    owner to "2023_urban_grzegorz";

