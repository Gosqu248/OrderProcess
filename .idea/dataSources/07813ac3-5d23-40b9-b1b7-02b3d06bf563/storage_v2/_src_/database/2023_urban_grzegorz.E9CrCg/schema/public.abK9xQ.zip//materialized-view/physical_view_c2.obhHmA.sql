create materialized view physical_view_c2 as
SELECT DISTINCT cwiczenie.kategoria
FROM aplikacja.cwiczenie;

alter materialized view physical_view_c2 owner to "2023_urban_grzegorz";

