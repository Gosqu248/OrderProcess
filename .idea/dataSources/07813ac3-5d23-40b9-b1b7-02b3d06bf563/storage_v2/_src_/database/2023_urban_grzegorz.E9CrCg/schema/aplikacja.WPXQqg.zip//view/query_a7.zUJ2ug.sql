create view query_a7(id_planu, id_jednostki, nr_dnia, nr_tygodnia) as
SELECT jednostka_treningowa.id_planu,
       jednostka_treningowa.id_jednostki,
       jednostka_treningowa.nr_dnia,
       jednostka_treningowa.nr_tygodnia
FROM aplikacja.jednostka_treningowa
WHERE jednostka_treningowa.id_planu = 10;

comment on view query_a7 is 'Wybór wszystkich jednostek treningowych o id planu=10';

alter table query_a7
    owner to "2023_urban_grzegorz";

