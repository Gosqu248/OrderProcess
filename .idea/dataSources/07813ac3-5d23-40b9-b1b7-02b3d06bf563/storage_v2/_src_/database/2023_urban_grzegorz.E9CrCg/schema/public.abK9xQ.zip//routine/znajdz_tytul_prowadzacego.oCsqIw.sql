create function znajdz_tytul_prowadzacego(p_imie character varying, p_nazwisko character varying) returns character varying
    language plpgsql
as
$$
DECLARE
    v_tytul VARCHAR;
BEGIN
    SELECT tytul INTO v_tytul
    FROM kadry.prowadzacy
    WHERE imie = p_imie AND nazwisko = p_nazwisko;
    
    IF FOUND THEN
        RETURN v_tytul;
    ELSE
        RETURN 'Brak informacji o prowadzącym.';
    END IF;
END;
$$;

alter function znajdz_tytul_prowadzacego(varchar, varchar) owner to "2023_urban_grzegorz";

