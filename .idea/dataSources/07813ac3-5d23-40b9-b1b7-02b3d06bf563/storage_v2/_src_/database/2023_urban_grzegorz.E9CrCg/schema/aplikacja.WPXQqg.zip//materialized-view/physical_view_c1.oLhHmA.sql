create materialized view physical_view_c1 as
SELECT produkt_spozywczy.nazwa_produktu,
       produkt_spozywczy.bialko
FROM aplikacja.produkt_spozywczy
ORDER BY produkt_spozywczy.bialko DESC
LIMIT 50;

alter materialized view physical_view_c1 owner to "2023_urban_grzegorz";

