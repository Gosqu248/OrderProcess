create function get_users_by_name(p_imie text)
    returns TABLE(id_uzytkownika bigint, imie text, nazwisko text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT u.id_uzytkownika, u.imie, u.nazwisko
    FROM aplikacja.uzytkownik u
    WHERE u.imie = p_imie;
END;
$$;

alter function get_users_by_name(text) owner to "2023_urban_grzegorz";

