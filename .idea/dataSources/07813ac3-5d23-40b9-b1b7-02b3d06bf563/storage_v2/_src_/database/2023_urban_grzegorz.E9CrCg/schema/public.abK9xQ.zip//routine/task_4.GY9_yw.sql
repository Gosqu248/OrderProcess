create function task_4() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.id_jednostki <> OLD.id_jednostki THEN
        -- Zaktualizuj liczbę prowadzących w starej jednostce organizacyjnej
        UPDATE kadry.jednostki_organizacyjne
        SET liczba_prowadzacych = liczba_prowadzacych - 1
        WHERE id = OLD.id_jednostki;
        
        -- Zaktualizuj liczbę prowadzących w nowej jednostce organizacyjnej
        UPDATE kadry.jednostki_organizacyjne
        SET liczba_prowadzacych = liczba_prowadzacych + 1
        WHERE id = NEW.id_jednostki;
    END IF;

    RETURN NEW;
END;
$$;

alter function task_4() owner to "2023_urban_grzegorz";

